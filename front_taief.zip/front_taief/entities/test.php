<?php
include 'php/rdv.php';
session_start();
$rdv = new rdv();
if(isset($_POST['specname'])){
    $params=$_POST['specname'];
    $doci = $rdv->getdoctorbycat($params);
    foreach($doci as $doc ){
     echo" <option>".$doc['name']."</option>";



    }


}    


?>