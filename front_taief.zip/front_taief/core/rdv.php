<?php  


	class rdv
	{
		private $servername = "localhost";
		private $username   = "root";
		private $password   = "";
		private $database   = "venuscare";
		public  $con;
		

		var $datadocs ;

		// Database Connection 
		public function __construct()
		{
		    $this->con = new mysqli($this->servername, $this->username,$this->password,$this->database);
		    if(mysqli_connect_error()) {
			 trigger_error("Failed to connect to MySQL: " . mysqli_connect_error());
		    }else{
			return $this->con;
		    }
		}

		// Insert customer data into customer table
		public function insertData($post)
		{
			$date = $this->con->real_escape_string($_POST['date']);
            $heure = $this->con->real_escape_string($_POST['time']);
            $id=$_SESSION['id'];
			//$username = $this->con->real_escape_string($_POST['username']);
            //$password = $this->con->real_escape_string(md5($_POST['password']));
            $query = "INSERT INTO rdv (date_rdv, heure, enabled, etat, id_docteur, id_patient) VALUES('$date', '$heure', '0', 'en cours', '2','$id')";
			//$query="INSERT INTO customers(name,email,username,password) VALUES('$name','$email','$username','$password')";
			$sql = $this->con->query($query);
			if ($sql==true) {
			    header("Location:index.php?add=success");
			}else{
                echo($query);
			    echo "add failed";
			}
		}
//SELECT * FROM `rdv` WHERE id_patient=1 
		// Fetch customer records for show listing
		public function displayData()
		{
           // $id=$_SESSION['id'];
		   // $query = "SELECT * FROM rdv WHERE id_patient = '$id'";
		   $query = "SELECT * FROM rdv ";
		    $result = $this->con->query($query);
		if ($result->num_rows > 0) {
		    $data = array();
		    while ($row = $result->fetch_assoc()) {
		           $data[] = $row;
			}
			 return $data;
		    }else{
			 echo "No found records";
		    }
        }
        
        

		// Fetch single data for edit from customer table
		public function getdoctorbyid($id)
		{
		    $query = "SELECT * FROM utilisateur WHERE id = '$id'";
		    $result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		    }else{
			echo "Record not found";
		    }
        }
		
		
		public function getdoctorbycat($idcati)
		{

		    $query = "SELECT * FROM utilisateur WHERE spec = '$idcati'";
			$result = $this->con->query($query);
			if ($result->num_rows > 0) {
				$data = array();
				while ($row = $result->fetch_assoc()) {
					   $data[] = $row;
				}
				 return $data;
				}else{
				 echo "No found records";
				}
        }


        public function getrdvbyid($id)
		{
		    $query = "SELECT * FROM rdv WHERE id = '$id'";
		    $result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		    }else{
			echo "Record not found";
		    }
		}








public function getdoctors()
{
	
	$query = "SELECT * FROM utilisateur WHERE role = 'docteur'";
	$result = $this->con->query($query);
if ($result->num_rows > 0) {
	$data = array();
	while ($row = $result->fetch_assoc()) {
		   $data[] = $row;
	}
	 return $data;
	}else{
	 echo "No found records";
	}
}










		public function userauth($post){

			  if(isset($_POST["submit"])) {
				  
				$password = $this->con->real_escape_string(md5($_POST['password']));
				$username = $this->con->real_escape_string($_POST['username']);
				$query = "SELECT * FROM customers WHERE username = '$username' && password ='$password' ";
				$sql = $this->con->query($query);
				$rowCount = mysqli_num_rows($sql);
				 echo ($rowCount);
				if ($rowCount > 0) {
				
				 while($row = mysqli_fetch_array($sql)) {
                    $id            = $row['id'];
					$username     = $row['username'];
					$role     = $row['role'];

					 $_SESSION['id'] = $id;
					   $_SESSION['username'] = $username;
					   
                   
				}
				
					if ($role!="admin"){
						header("Location:index.php?login=true");
					} 
					else {
						header("Location:../admin/index.php?login=true");
					}
				                

			}else{
              
			    echo "login failed try again!";
			}


			  }




		}

		// Update customer data into customer table
		public function updateRecord($postData)
		{
		    $daterep = $this->con->real_escape_string($_POST['date']);
		    $heurerep = $this->con->real_escape_string($_POST['heure']);
		    $id = $this->con->real_escape_string($_POST['id']);
		if (!empty($id) && !empty($postData)) {
			$query = "UPDATE rdv SET date_rdv = '$daterep', heure = '$heurerep'  WHERE id = '$id'";
			$sql = $this->con->query($query);
			if ($sql==true) {
			    header("Location:../medlife/reservation.php");
			}else{
			    echo "Registration updated failed try again!";
			}
		    }
			
		}


		// Delete customer data from customer table
		public function deleteRecord($id)
		{
		    $query = "DELETE FROM rdv WHERE id = '$id'";
		    $sql = $this->con->query($query);
		if ($sql==true) {
			header("Location:../medlife/reservation.php?msg3=delete");
		}else{
			echo "Record does not delete try again";
		    }
		}

	}
?>