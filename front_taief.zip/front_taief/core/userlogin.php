<?php
class user {
	private $servername = "localhost";
		private $username   = "root";
		private $password   = "";
		private $database   = "venuscare";
		public  $con;


public function __construct()
		{
		    $this->con = new mysqli($this->servername, $this->username,$this->password,$this->database);
		    if(mysqli_connect_error()) {
			 trigger_error("Failed to connect to MySQL: " . mysqli_connect_error());
		    }else{
			return $this->con;
		    }
        }
        


 public function userauth($post){

			  if(isset($_POST["submit"])) {
				  
				$password = $this->con->real_escape_string($_POST['password']);
				$username = $this->con->real_escape_string($_POST['username']);
				echo ($username);
				$query = "SELECT * FROM utilisateur WHERE username = '$username' && password ='$password' ";
				$sql = $this->con->query($query);
				$rowCount = mysqli_num_rows($sql);
				 
				if ($rowCount > 0) {
				
				 while($row = mysqli_fetch_array($sql)) {
					 
                    $id            = $row['id'];
					$username     = $row['username'];
					$name= $row['name'];
					  $role     = $row['role'];

					  $_SESSION['id'] = $id;
					$_SESSION['username'] = $username;
					$_SESSION['name']=$name;
					$_SESSION['role']=$role;
				 
				 }
				
				
				
					if ($role=="docteur"){
						header("Location:index.php?login=true");
					} 
					else if($role=="admin") {
						header("Location:../medlife/backoffice");
					}	
					else {
						header("Location:index.php?login=true");
					}
				}
				                

			else{
              
			    echo "login failed try again!";
			}


			  }




		}
       




}
 


?>