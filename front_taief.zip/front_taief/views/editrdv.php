<?php
  
  // Include database file
    include 'php/rdv.php';
    session_start();
  $rdv = new rdv();
 

  // Delete record from table
     if(isset($_GET['editId']) && !empty($_GET['editId'])) {
    $editId = $_GET['editId'];
    $rendezvous = $rdv->getrdvbyid($editId);
  }

  // Update Record in customer table
  if(isset($_POST['update'])) {
    $rdv->updateRecord($_POST);
  }  
    
     
?> 



<!DOCTYPE html>

<html>
    <head> </head>
    <body>
        <div class="container">
  <form action="" method="POST">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" name="uname" value="<?php echo $rendezvous['date_rdv']; ?>" required="">
    </div>
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" name="uemail" value="<?php echo $rendezvous['heure']; ?>" required="">
    </div>
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" class="form-control" name="upname" value="<?php echo $rendezvous['etat']; ?>" required="">
    </div>
    <div class="form-group">
      <input type="hidden" name="id" value="<?php echo $rendezvous['id']; ?>">
      <input type="submit" name="update" class="btn btn-primary" style="float:right;" value="Update">
    </div>
  </form>
</div>

    </body>
</html>