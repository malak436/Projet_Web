<?php
  
  // Include database file
    include 'php/rdv.php';
    session_start();
  $rdv = new rdv();
 
 if(isset($_GET['deleteId']) && !empty($_GET['deleteId'])) {
      $deleteId = $_GET['deleteId'];
      $rdv->deleteRecord($deleteId);
  }
  // Delete record from table

     
?> 


<!DOCTYPE html>
<html lang="en">
  <meta http-equiv="content-type" content="text/html;charset=utf-8" />
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Venus Curae- Health &amp; Medical Template | Home</title>

    <!-- Favicon  -->
    <link rel="icon" href="assets/img/core-assets/img/favicon.ico" />

    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/style.css" />
  </head>

  <body>
    <!-- Preloader -->
    <!-- <div id="preloader">
      <div class="medilife-load"></div>
    </div> -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area">
      <!-- Top Header Area -->
      <div class="top-header-area">
        <div class="container h-100">
          <div class="row h-100">
            <div class="col-12 h-100">
              <div
                class="h-100 d-md-flex justify-content-between align-items-center"
              >


                 <?php
            if(!empty($_SESSION['id'])){   
            echo"<p>  Welcome <span>" . $_SESSION['username'] . "</span></p>";
        }else {
          echo"<p>Welcome to <span>Venus Curae</span></p>";
        }
    ?>

                <p>Welcome to <span>Venus Curae</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Header Area -->
      <div class="main-header-area" >
        <div class="container h-100">
          <div class="row h-100 align-items-center">
            <div class="col-12 h-100">
              <div class="main-menu h-100">
                <nav class="navbar h-100 navbar-expand-lg">
                  <!-- Logo Area  -->
                  <a class="navbar-brand" href="index-2.html"
                    ><img src="assets/img/core-assets/img/logo.png" alt="Logo"
                  /></a>

                  <button
                    class="navbar-toggler"
                    type="button"
                    data-toggle="collapse"
                    data-target="#VenusCureaMenu"
                    aria-controls="VenusCureaMenu"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <span class="navbar-toggler-icon"></span>
                  </button>

                  <div class="collapse navbar-collapse" id="VenusCureaMenu">
                    <!-- Menu Area -->
                    <ul class="navbar-nav ml-auto">
                      <li class="nav-item active">
                        <a class="nav-link" href="index.php"
                          >Home <span class="sr-only">(current)</span></a
                        >
                      </li>
                      <li class="nav-item dropdown">
                        <a
                          class="nav-link dropdown-toggle"
                          href="#"
                          id="navbarDropdown"
                          role="button"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                          >Pages</a
                        >
                        <div
                          class="dropdown-menu"
                          aria-labelledby="navbarDropdown"
                        >
                          <a class="dropdown-item" href="index-2.html">Home</a>
                          <a class="dropdown-item" href="about-us.html"
                            >About Us</a
                          >
                          <a class="dropdown-item" href="services.html"
                            >Services</a
                          >
                          <a class="dropdown-item" href="blog.html">News</a>
                          <a class="dropdown-item" href="single-blog.html"
                            >News Details</a
                          >
                          <a class="dropdown-item" href="contact.html"
                            >Contact</a
                          >
                          <a class="dropdown-item" href="elements.html"
                            >Elements</a
                          >
                          <a class="dropdown-item" href="index-icons.html"
                            >All Icons</a
                          >
                        </div>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="about-us.html">About Us</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="services.html">Services</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="blog.html">News</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="reservation.php">Mes reservation</a>
                      </li>
                    </ul>
                    <!-- Appointment Button -->
                    <a href="#" class="btn medilife-appoint-btn ml-30"
                      > <span>login</span></a
                    >
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <section class="breadcumb-area bg-img gradient-background-overlay" style="background-image: url(assets/img/bg-img/breadcumb2.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-content">
                        <h3 class="breadcumb-title">News</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Hero Area Start ***** -->
  
    <!-- ***** Hero Area End ***** -->

    <!-- ***** Book An Appoinment Area Start ***** -->
<section class="medilife-blog-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                     <?php
    if (isset($_GET['msg1']) == "insert") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Your Registration added successfully
            </div>";
      } 
    if (isset($_GET['msg2']) == "update") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Your Registration updated successfully
            </div>";
    }
    if (isset($_GET['msg3']) == "delete") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Record deleted successfully
            </div>";
    }
  ?>

                        <!-- Post Thumbnail -->
                       
                        <!-- Post Content -->
                       
                           <table class="table ">
  <thead class="thead-dark">
    <tr>
      <th scope="col">nom</th>
      <th scope="col">docteur</th>
      <th scope="col">numero</th>
      <th scope="col">date</th>
      <th scope="col">heure</th>
      <th scope="col">action</th>



    </tr>
  </thead>
  <tbody>
         <?php 
          $rdva = $rdv->displayData(); 

          foreach ($rdva as $rdvs) {
           

                                 $doctor=$rdv->getdoctorbyid($rdvs['id_docteur']);



              if(strcmp($rdvs['etat'],"en cours")==0){
                  echo("<tr class='table-warning'>");
              } else if(strcmp($rdvs['etat'],"annulee")==0) {
                  echo ("<tr class='table-danger'>");
              } else {
                 echo ("<tr class='table-success'>");
              }

        ?>
  
      <th scope="row"> <?php echo( $rdvs['id_patient']) ;?></th>
      <td><?php echo($doctor['name']) ;?></td>
      <td><?php echo( $doctor['phone']) ;?></td>
      <td><?php echo( $rdvs['date_rdv']) ;?></td>
      <td><?php echo( $rdvs['heure']) ;?></td>
      <td><a href="editrdv.php?editId=<?php echo $rdvs['id'] ?>" class="btn btn-success">Modifier</a>
  
          <a href="reservation.php?deleteId=<?php echo $rdvs['id'] ?>"  class="btn btn-danger">Supprimer</a>
    </td>
        

    </tr>
    <?php } ?>
  
  </tbody>
</table>


                        
                    </div>

                   
                    <!-- Leave A Comment -->
                 
                </div>

                
            </div>
       
    </section>
    <!-- ***** Book An Appoinment Area End ***** -->

    <!-- ***** About Us Area Start ***** -->

    <!-- ***** Emergency Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area section-padding-100">
      <!-- Main Footer Area -->
      <div class="main-footer-area">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12 col-sm-6 col-xl-3">
              <div class="footer-widget-area">
                <div class="footer-logo">
                  <img src="assets/img/core-assets/img/logo.png" alt="" />
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
                  diam nonummy nibh euismod tincidunt ut laoreet dolore magna
                  aliquam erat volutpat. Lorem ipsum dolor sit amet,
                  consectetuer.
                </p>
                <div class="footer-social-info">
                  <a href="#"
                    ><i class="fa fa-google-plus" aria-hidden="true"></i
                  ></a>
                  <a href="#"
                    ><i class="fa fa-pinterest" aria-hidden="true"></i
                  ></a>
                  <a href="#"
                    ><i class="fa fa-facebook" aria-hidden="true"></i
                  ></a>
                  <a href="#"
                    ><i class="fa fa-twitter" aria-hidden="true"></i
                  ></a>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
              <div class="footer-widget-area">
                <div class="widget-title">
                  <h6>Latest News</h6>
                </div>
                <div class="widget-blog-post">
                  <!-- Single Blog Post -->
                  <div class="widget-single-blog-post d-flex">
                    <div class="widget-post-thumbnail">
                      <img src="assets/img/blog-img/ln1.jpg" alt="" />
                    </div>
                    <div class="widget-post-content">
                      <a href="#">Better Health Care</a>
                      <p>Dec 02, 2017</p>
                    </div>
                  </div>
                  <!-- Single Blog Post -->
                  <div class="widget-single-blog-post d-flex">
                    <div class="widget-post-thumbnail">
                      <img src="assets/img/blog-img/ln2.jpg" alt="" />
                    </div>
                    <div class="widget-post-content">
                      <a href="#">A new drug is tested</a>
                      <p>Dec 02, 2017</p>
                    </div>
                  </div>
                  <!-- Single Blog Post -->
                  <div class="widget-single-blog-post d-flex">
                    <div class="widget-post-thumbnail">
                      <img src="assets/img/blog-img/ln3.jpg" alt="" />
                    </div>
                    <div class="widget-post-content">
                      <a href="#">Health department advice</a>
                      <p>Dec 02, 2017</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
              <div class="footer-widget-area">
                <div class="widget-title">
                  <h6>Contact Form</h6>
                </div>
                <div class="footer-contact-form">
                  <form action="#" method="post">
                    <input
                      type="text"
                      class="form-control border-top-0 border-right-0 border-left-0"
                      name="footer-name"
                      id="footer-name"
                      placeholder="Name"
                    />
                    <input
                      type="email"
                      class="form-control border-top-0 border-right-0 border-left-0"
                      name="footer-email"
                      id="footer-email"
                      placeholder="Email"
                    />
                    <textarea
                      name="message"
                      class="form-control border-top-0 border-right-0 border-left-0"
                      id="footerMessage"
                      placeholder="Message"
                    ></textarea>
                    <button type="submit" class="btn medilife-btn">
                      Contact Us <span>+</span>
                    </button>
                  </form>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
              <div class="footer-widget-area">
                <div class="widget-title">
                  <h6>News Letter</h6>
                </div>

                <div class="footer-newsletter-area">
                  <form action="#">
                    <input
                      type="email"
                      class="form-control border-0 mb-0"
                      name="newsletterEmail"
                      id="newsletterEmail"
                      placeholder="Your Email Here"
                    />
                    <button type="submit">Subscribe</button>
                  </form>
                  <p>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
                    sed diam nonummy nibh euismod tincidunt ut laoreet dolore
                    magna aliquam erat volutpat. Lorem ipsum dolor sit amet,
                    consectetuer.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Bottom Footer Area -->
      <div class="bottom-footer-area">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="bottom-footer-content">
                <!-- Copywrite Text -->
                <div class="copywrite-text">
                  <p>
                    <a target="_blank" href="https://www.templateshub.net"
                      >Templates Hub</a
                    >
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="assets/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper assets/js -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Bootstrap assets/js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Plugins assets/js -->
    <script src="assets/js/plugins.js"></script>
    <!-- Active assets/js -->
    <script src="assets/js/active.js"></script>
  </body>
</html>
