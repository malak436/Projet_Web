<?PHP
include "../../controller/centreC.php";

$associ=new centreC();
if (isset($_POST["id"])){
    $associ->supprimer($_POST["id"]);

    header('Location: listecentre.php');
}

?>