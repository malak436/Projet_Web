<?PHP
include "../../controller/associationC.php";

$associ=new associationC();
if (isset($_POST["id"])){
    $associ->supprimerAssociation($_POST["id"]);

    header('Location: listeassociation1.php');
}

?>