<?php
include "../../entity/centre.php";
include "../../controller/centreC.php";

if (isset($_POST['id']) ){

    $centreC = new  centreC();
    $centre = new centre($_POST['id'],$_POST['nom'],$_POST['adresse'],$_POST['email'],$_POST['tel'],$_POST['dateAjout'],$_POST['dateModif'],$_POST['etat'],$_POST['nom']
    );

    $centreC->ajouterCentre($centre);
    header('Location: listecentre.php');
    //var_dump($centre);

}


?>