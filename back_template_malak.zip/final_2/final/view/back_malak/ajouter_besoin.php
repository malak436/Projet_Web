<?php
include "../../entity/besoin.php";
include "../../controller/besoinC.php";

if (isset($_POST['id']) ){

    $besoinC = new  besoinsC();
    $besoin = new besoins($_POST['id'],$_POST['nom'],$_POST['description']
    );

    $besoinC->ajouterb($besoin);
    header('Location: listebesoin.php');
//var_dump($besoin);
}


?>