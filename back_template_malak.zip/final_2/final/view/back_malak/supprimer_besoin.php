<?PHP
include "../../controller/besoinC.php";

$besoin=new besoinsC();
if (isset($_POST["id"])){
    $besoin->supprimerb($_POST["id"]);

    header('Location: listebesoin.php');
}

?>