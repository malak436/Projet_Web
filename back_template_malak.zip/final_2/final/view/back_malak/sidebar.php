<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>Preclinic - Medical & Hospital - Bootstrap 4 Admin Template</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.min.js"></script>
    <script src="assets/js/respond.min.js"></script>
    <![endif]-->
</head>

<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    <div class="sidebar" id="sidebar">
        <div class="sidebar-inner slimscroll">
            <div id="sidebar-menu" class="sidebar-menu">
                <ul>
                    <li class="menu-title">Main</li>
                    <li class="active">
                        <a href="index-2.php"><i class="fa fa-dashboard"></i> <span>Tableau de Bord</span></a>
                    </li>
                    <li>
                        <a href="doctors.php"><i class="fa fa-user-md"></i> <span>Docteurs</span></a>
                    </li>
                    <li>
                        <a href="patients.php"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                    </li>
                    <li>
                        <a href="appointments.php"><i class="fa fa-calendar"></i> <span>RDV</span></a>
                    </li>
                    <li>
                        <a href="departments.php"><i class="fa fa-calendar"></i> <span>Départements</span></a>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-envelope"></i> <span> Associations</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <li><a href="listeassociation1.php">Liste Association</a></li>
                            <li><a href="listebesoin.php"> Liste besoins Associations</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-envelope"></i> <span> Evènements</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="ajouterEvent.php">Ajouter Evenement</a></li>
                            <li><a href="modifierEvent.php">Modifier Evenement</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-envelope"></i> <span> Medecins Volontaires</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="ajouterMed.php">Ajouter volontaire</a></li>
                            <li><a href="modifierMed.php">Modifier volontaire</a></li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#"><i class="fa fa-envelope"></i> <span> Centres</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <li><a href="listecentre.php">Liste des centres</a></li>
                            <li><a href="listetype.php">Liste des types des centres</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-envelope"></i> <span> Email</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="compose.php">Nouveau Mail</a></li>
                            <li><a href="inbox.php">Boîte de reception</a></li>
                            <li><a href="mail-view.php">Liste Mail</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-commenting-o"></i> <span> Blog</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Liste Blog</a></li>
                            <li><a href="add-blog.html">Ajouter Blog</a></li>
                            <li><a href="edit-blog.html">Modifier Blog</a></li>
                        </ul>
                    </li>

                    </li>
                    <li class="menu-title">UI Elements</li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-laptop"></i> <span>Composants</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="uikit.php">UI Kit</a></li>
                            <li><a href="typography.php">Typographie</a></li>
                            <li><a href="tabs.php">Tableaux</a></li>
                        </ul>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-edit"></i> <span> Formulaire</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="form-basic-inputs.php">Entrées de base</a></li>
                            <li><a href="form-input-groups.php">Groupes d'entrées</a></li>
                            <li><a href="form-horizontal.php">Formulaire Horizontale</a></li>
                            <li><a href="form-vertical.php"> Formulaire Verticale</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-table"></i> <span> Tableaux</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="tables-basic.php">Tableaux basiques</a></li>
                            <li><a href="tables-datatables.php">Tableau de données</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="calendar.php"><i class="fa fa-calendar"></i> <span>Calendrier</span></a>
                    </li>
                    <li class="menu-title">Extras</li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-columns"></i> <span>Pages</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="login.html"> Connecter </a></li>
                            <li><a href="register.html">S'inscire </a></li>
                            <li><a href="forgot-password.html"> Mot de passe oublié </a></li>
                            <li><a href="change-password2.html"> Modifier mot de passe </a></li>
                            <li><a href="lock-screen.html"> Ecran verrouillé </a></li>
                            <li><a href="profile.html"> Profil </a></li>
                            <li><a href="gallery.html"> Gallerie </a></li>
                            <li><a href="error-404.html">404 Error </a></li>
                            <li><a href="error-500.html">500 Error </a></li>
                            <li><a href="blank-page.html"> Page Vide </a></li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</ul>
</html>
