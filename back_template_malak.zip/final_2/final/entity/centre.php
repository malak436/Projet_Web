<?php
class centre

{
    private $id;
    private   $nom;
    private  $adresse;
    private  $email;
    private $tel;
    private $dateAjout;
    private $dateModif;
    private $etat;
    private $idtype;


    function __construct($id,$nom,$adresse,$email,$tel,$dateAjout,$dateModif,$etat,$idtype ){
        $this->id=$id;
        $this->nom=$nom;
        $this->adresse=$adresse;
        $this->email=$email;
        $this->tel=$tel;
        $this->dateAjout=$dateAjout;
        $this->dateModif=$dateModif;
        $this->etat=$etat;
        $this->idtype=$idtype;
    }
    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;

        return $this;
    }
    function getnom()
    {
        return $this->nom;
    }
    function getadresse()
    {
        return $this->adresse ;
    }
    function gettel()
    {
        return $this->tel;
    }

    function getemail()
    {
        return $this->email;
    }

    function getdateAjout()
    {
        return $this->dateAjout;
    }
    function getdateModif()
    {
        return $this->dateModif;
    }
    function getetat()
    {
        return $this->etat;
    }
    function getidtype()
    {
        return $this->idtype;
    }
    function setnom($nom)
    {
        $this->nom=$nom;
    }
    function setadresse($adresse)
    {
        $this->adresse=$adresse;
    }
    function setemail($email)
    {
        $this->email=$email;
    }
    function settel($tel)
    {
        $this->tel=$tel;
    }

    function setdateAjout($dateAjout)
    {
        $this->dateAjout=$dateAjout;
    }
    function setdateModif($dateModif)
    {
        $this->dateModif=$dateModif;
    }
    function setetat($etat)
    {
        $this->etat=$etat;
    }
    function setidtype($idtype)
    {
        $this->idtype=$idtype;
    }
}
?>