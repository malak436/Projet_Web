<?php
class association

{
    private $id;
    private   $titre;
    private   $description;
    private  $adresse;
    private $dateCrea;
    private  $image;
    private $dateAjout;
    private $dateModif;
    private $etat;
    private  $email;
    private $tel;
    private $idbesoin;


    function __construct($id,$titre,$email,$tel,$description,$dateCrea,$adresse,$image,$dateAjout,$dateModif,$etat,$idbesoin){
        $this->id=$id;
        $this->titre=$titre;
        $this->email=$email;
        $this->tel=$tel;
        $this->description=$description;
        $this->dateCrea=$dateCrea;
        $this->adresse=$adresse;
        $this->image=$image;
        $this->dateAjout=$dateAjout;
        $this->dateModif=$dateModif;
        $this->etat=$etat;
        $this->idbesoin=$idbesoin;

    }
    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;

        return $this;
    }
    function gettitre()
    {
        return $this->titre;
    }
    function gettel()
    {
        return $this->tel;
    }

    function getemail()
    {
        return $this->email;
    }
    function getdescription()
    {
        return $this->description;
    }

    function getadresse()
    {
        return $this->adresse ;
    }
    function getdateCrea()
    {
        return $this->dateCrea ;
    }

    function getimage()
    {
        return $this->image;
    }
    function getdateAjout()
    {
        return $this->dateAjout;
    }
    function getdateModif()
    {
        return $this->dateModif;
    }
    function getetat()
    {
        return $this->etat;
    }

   function getidbesoin()
    {
        return $this->idbesoin ;
    }
    function setdescription($description)
    {
        $this->description=$description;
    }
    function setemail($email)
    {
        $this->email=$email;
    }
    function settel($tel)
    {
        $this->tel=$tel;
    }
    function settitre($titre)
    {
        $this->titre=$titre;
    }
    function setadresse($adresse)
    {
        $this->adresse=$adresse;
    }
    function setdateCrea($dateCrea)
    {
        $this->dateCrea=$dateCrea;
    }

    function setimage($image)
    {
        $this->image=$image;
    }
    function setdateAjout($dateAjout)
    {
        $this->dateAjout=$dateAjout;
    }
    function setdateModif($dateModif)
    {
        $this->dateModif=$dateModif;
    }
    function setetat($etat)
    {
        $this->etat=$etat;
    }
    function setidbesoin($idbesoin)
    {
        $this->idbesoin = $idbesoin;
    }
}
?>