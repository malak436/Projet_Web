<?php
include "../../entity/association.php";
include "../../controller/associationC.php";

if (isset($_POST['id']) ){
    
    $associC = new  associationC();
    $associ = new association($_POST['id'],$_POST['titre'],$_POST['email'],$_POST['tel'],$_POST['description'],$_POST['dateCrea'],$_POST['adresse'],$_POST['image'],$_POST['dateAjout'],$_POST['dateModif'],$_POST['etat']
);

$associC->ajouterAssociation($associ);
header('Location: listeassociation1.php');

    }


?>