<?PHP
require_once "config.php";


class associationC
{
    function ajouterAssociation($association)
{
    $sql = "insert into association (id,titre,email,tel,description,dateCrea,adresse,image,dateModif,dateAjout,etat) values (:id,:titre,:email,:tel,:description,:dateCrea,:adresse,:image,:dateModif,:dateAjout,:etat)";
    $db = config::getConnexion();
    try {
        $req = $db->prepare($sql);

        $req->bindValue(':id', $association->getid());    
        $req->bindValue(':titre', $association->gettitre());
        $req->bindValue(':email', $association->getemail());
        $req->bindValue(':tel', $association->gettel());
        $req->bindValue(':description', $association->getdescription());
        $req->bindValue(':dateCrea', $association->getdateCrea());
        $req->bindValue(':adresse', $association->getadresse());
        $req->bindValue(':image', $association->getimage());
        $req->bindValue(':dateModif', $association->getdateModif());
        $req->bindValue(':dateAjout', $association->getdateAjout());
        $req->bindValue(':etat', $association->getetat());
        

        $req->execute();

    } catch (Exception $e) {
        echo 'Erreur: ' . $e->getMessage();
    }
}

    function afficher()
    {
        $sql = "SELECT * from association";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }


    function supprimerAssociation($id)
    {
        $sql = "DELETE FROM association WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }
    function recupererAssociation($id){
        $sql="SELECT * from association where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }




    function modifierAssociation($association, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE association SET 
						titre = :titre, 
						description = :description,
						dateCrea = :dateCrea,
						adresse= :adresse,
						image = :image,
						dateModif = :dateModif,
						tel = :tel,
						email = :email,
						dateAjout=:dateAjout,
						etat = :etat
					WHERE id = :id'
            );

            $query->execute([
                'titre'=>$association->gettitre(),
                'description'=>$association->getdescription(),
                'dateCrea'=>$association->getdateCrea(),
                'adresse'=>$association->getadresse(),
                'image'=>$association->getimage(),
                'dateModif'=>$association->getdateModif(),
                'dateAjout'=>$association->getdateAjout(),
                'etat'=>$association->getetat(),
                'email'=>$association->getemail(),
                'tel'=>$association->gettel(),
                'id'=>$id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }


}
?>